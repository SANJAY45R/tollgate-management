using System.ComponentModel.DataAnnotations;
#nullable disable
namespace Tollgate.Dto
{
    public class AdminLoginDto
    {
         [Required]
        public string AdminName{get;set;}

        [Required]
        public string Password{get;set;}

        
    }
}