namespace Tollgate.Dto
{
    public class TollfeesDto
    {

        public int VehicleClassId { get; set; }

        public long vehicleId{get;set;}
        public long TollPlazzaOperatorId { get; set; }
        public int LaneId { get; set; }

        public bool IsAvailableFastTagId { get; set; }

        public bool IsValidCard { get; set; }
        public double Amount { get; set; }

    }
}