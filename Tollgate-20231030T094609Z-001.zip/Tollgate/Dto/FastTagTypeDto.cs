using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using OfficeOpenXml.FormulaParsing.Excel.Functions.Finance.FinancialDayCount;

namespace Tollgate.Dto
{
    #nullable disable
    public class FastTagTypeDto
    {
         public string FastTagTypeName{get;set;}
       
         public int BasisId{get;set;}

         public long VehicleId{get;set;}

         public double Amount{get;set;}
        
        
    }
}