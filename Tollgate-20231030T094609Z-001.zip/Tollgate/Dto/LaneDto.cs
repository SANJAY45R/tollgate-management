namespace Tollgate.Dto
{
    #nullable disable

    public class LaneDto
    {
        public long BoothId{get;set;}

        public string LaneName{get;set;}

        
    }
}
