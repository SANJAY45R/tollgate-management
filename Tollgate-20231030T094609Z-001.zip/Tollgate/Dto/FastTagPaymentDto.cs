using System.ComponentModel.DataAnnotations.Schema;
using Tollgate.Models;

namespace Tollgate.Dto
#nullable disable
{
    public class FastTagPaymentDto
    {
        public double Amount { get; set; }
        [ForeignKey("FastTagId")]
        public long FastTagId { get; set;}


        // public DateTime PaymentDate { get; set; }
        public string PaymentMethod { get; set; }
        // public string TransactionId { get; set; }
        // public bool IsSuccessful { get; set; }

        // public FasttagRegisteration fasttagRegisteration{get;set;}


    }
}