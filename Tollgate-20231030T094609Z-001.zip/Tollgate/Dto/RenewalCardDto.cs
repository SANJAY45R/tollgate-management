namespace Tollgate.Dto
{
    public class RenewalCardDto
    {
        public long FastTagId { get; set; }

        // public long VehicleId{get;set;}

        // public DateTime RenewalDate { get; set; }
        // public long PaymentId { get; set; }



    }
}