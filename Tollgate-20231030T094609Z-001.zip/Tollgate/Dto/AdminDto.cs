namespace Tollgate.Dto;
using System.ComponentModel.DataAnnotations;
#nullable disable
    public class AdminDto
    {
         [Required]
        public string AdminName{get;set;}

        [Required]
        public string Password{get;set;}

        public string Role{get;set;}
        
        public string Address{get;set;}
        [Phone]
        public string PhoneNumber{get;set;}
        [EmailAddress]
        public string Email{get;set;}

        public string FirstName{get;set;}

        public char LastName{get;set;}
        
    }
