namespace Tollgate.Dto
{
    #nullable disable
    public class RatingDto
    {
        public string RatingCategoryName{get;set;}
        
    }
}