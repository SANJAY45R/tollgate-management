using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tollgate.Models;

namespace Tollgate.Dto
{
    #nullable disable
    public class FasttagRegisterationDto
    {
        [Required]
        public long VehicleId { get; set; }
        // public string FeedBack { get; set; }
        [Required]
        public int FastTagTypeid { get; set; }
        // public bool RegistrationStatus { get; set; }
        

    }
}