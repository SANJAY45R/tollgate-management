namespace Tollgate.Dto
{
    #nullable disable
    public class VehicleClassDto
    {
        public string VehicleName{get;set;}
    }
}