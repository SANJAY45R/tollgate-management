using Microsoft.EntityFrameworkCore.Storage;

namespace Tollgate.Dto
{
    #nullable disable
    public class RegisterationFeedbackDto
    {
        public int Ratingid{get;set;}

        public string FeedBack{get;set;}
    }
}