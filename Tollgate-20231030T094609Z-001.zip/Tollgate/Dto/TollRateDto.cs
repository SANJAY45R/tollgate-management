namespace Tollgate.Dto
{
    public class TollRateDto
    {
        public int VehicleClassId{get;set;}
        public double TollAmount{get;set;}

        public DateTime EffectiveDate{get;set;} 
         public long BoothId{get;set;}
        
    }
}