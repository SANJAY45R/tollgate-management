namespace Tollgate.Dto
{
    #nullable disable
    public class FasttagpayDto
    {
       
        public FastTagTypeDto fastTagTypeDto{get;set;}
        public FastTagPaymentDto fastTagPaymentDto{get;set;}

        
    }
}