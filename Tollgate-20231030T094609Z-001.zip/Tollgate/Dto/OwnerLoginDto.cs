namespace Tollgate.Dto
{
    #nullable disable
    public class OwnerLoginDto
    {
        public string OwnerName{get;set;}

        public string Password{get;set;}
        
    }
}