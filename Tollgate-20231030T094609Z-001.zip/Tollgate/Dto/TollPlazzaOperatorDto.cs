using System.ComponentModel.DataAnnotations;
#nullable disable

namespace Tollgate.Dto
{
    public class TollPlazzaOperatorDto
    {
         public string UserName{get;set;}

        [Required]
        public string Password{get;set;}

        public string Role{get;set;}
        
        public string Address{get;set;}
        [Phone]
        public string PhoneNumber{get;set;}
        [EmailAddress]
        public string Email{get;set;}

        public string FirstName{get;set;}

        public char LastName{get;set;}

        public bool IsDeleted{get;set;}
       
        
    }
}