namespace Tollgate.Dto
{
    #nullable disable
    public class VehicleDto
    {
        public string RegistrationNumber { get; set; }

        

        public int VehicleClassId { get; set; }
        public long OwnerId { get; set; }
    }
}