namespace Tollgate.Dto
{
    public class PaymentDto
    {
        
    }
}