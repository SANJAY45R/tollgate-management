namespace Tollgate.Dto
{
    #nullable disable
    public class BasisDto
    {
        public string BasisName{get;set;}
    }
}