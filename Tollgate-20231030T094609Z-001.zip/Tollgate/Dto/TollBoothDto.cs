namespace Tollgate.Dto
{
    #nullable disable
    public class TollBoothDto
    {
        public string Location { get; set; }
        public long AdminId { get; set; }

        public bool Isopen { get; set; }


    }
}