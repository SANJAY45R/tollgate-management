﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tollgate.Migrations
{
    /// <inheritdoc />
    public partial class Isdeltoll : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<bool>(
                name: "IsDeleted",
                table: "TollPlazzaOperators",
                type: "boolean",
                nullable: false,
                defaultValue: false);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "IsDeleted",
                table: "TollPlazzaOperators");
        }
    }
}
