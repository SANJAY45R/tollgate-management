﻿using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Tollgate.Migrations
{
    /// <inheritdoc />
    public partial class Addbasis : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "BasisId",
                table: "FastTagTypes",
                type: "integer",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.CreateTable(
                name: "Basis",
                columns: table => new
                {
                    BasisId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BasisName = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Basis", x => x.BasisId);
                });

            migrationBuilder.CreateIndex(
                name: "IX_FastTagTypes_BasisId",
                table: "FastTagTypes",
                column: "BasisId");

            migrationBuilder.AddForeignKey(
                name: "FK_FastTagTypes_Basis_BasisId",
                table: "FastTagTypes",
                column: "BasisId",
                principalTable: "Basis",
                principalColumn: "BasisId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FastTagTypes_Basis_BasisId",
                table: "FastTagTypes");

            migrationBuilder.DropTable(
                name: "Basis");

            migrationBuilder.DropIndex(
                name: "IX_FastTagTypes_BasisId",
                table: "FastTagTypes");

            migrationBuilder.DropColumn(
                name: "BasisId",
                table: "FastTagTypes");
        }
    }
}
