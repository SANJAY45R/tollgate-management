﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;
using Npgsql.EntityFrameworkCore.PostgreSQL.Metadata;

#nullable disable

namespace Tollgate.Migrations
{
    /// <inheritdoc />
    public partial class MigrationCreate : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    AdminId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    AdminName = table.Column<string>(type: "text", nullable: false),
                    Password = table.Column<string>(type: "text", nullable: false),
                    Role = table.Column<string>(type: "text", nullable: true),
                    Address = table.Column<string>(type: "text", nullable: true),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true),
                    FirstName = table.Column<string>(type: "text", nullable: true),
                    LastName = table.Column<char>(type: "character(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.AdminId);
                });

            migrationBuilder.CreateTable(
                name: "FastTagTypes",
                columns: table => new
                {
                    FastTagTypeid = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FastTagTypeName = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FastTagTypes", x => x.FastTagTypeid);
                });

            migrationBuilder.CreateTable(
                name: "Owners",
                columns: table => new
                {
                    OwnerId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    OwnerName = table.Column<string>(type: "text", nullable: true),
                    Password = table.Column<string>(type: "text", nullable: true),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    Address = table.Column<string>(type: "text", nullable: true),
                    DateOfBirth = table.Column<DateTime>(type: "timestamp with time zone", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Owners", x => x.OwnerId);
                });

            migrationBuilder.CreateTable(
                name: "Ratings",
                columns: table => new
                {
                    Ratingid = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RatingCategoryName = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Ratings", x => x.Ratingid);
                });

            migrationBuilder.CreateTable(
                name: "TollPlazzaOperators",
                columns: table => new
                {
                    TollPlazzaOperatorId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    UserName = table.Column<string>(type: "text", nullable: false),
                    Password = table.Column<string>(type: "text", nullable: false),
                    Role = table.Column<string>(type: "text", nullable: true),
                    Address = table.Column<string>(type: "text", nullable: true),
                    PhoneNumber = table.Column<string>(type: "text", nullable: true),
                    Email = table.Column<string>(type: "text", nullable: true),
                    FirstName = table.Column<string>(type: "text", nullable: true),
                    LastName = table.Column<char>(type: "character(1)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TollPlazzaOperators", x => x.TollPlazzaOperatorId);
                });

            migrationBuilder.CreateTable(
                name: "VehicleClasses",
                columns: table => new
                {
                    VehicleClassId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    VehicleName = table.Column<string>(type: "text", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_VehicleClasses", x => x.VehicleClassId);
                });

            migrationBuilder.CreateTable(
                name: "TollBooths",
                columns: table => new
                {
                    BoothId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Location = table.Column<string>(type: "text", nullable: true),
                    AdminId = table.Column<long>(type: "bigint", nullable: false),
                    Isopen = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TollBooths", x => x.BoothId);
                    table.ForeignKey(
                        name: "FK_TollBooths_Admins_AdminId",
                        column: x => x.AdminId,
                        principalTable: "Admins",
                        principalColumn: "AdminId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Vehicles",
                columns: table => new
                {
                    VehicleId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    RegistrationNumber = table.Column<long>(type: "bigint", nullable: false),
                    VehicleClassId = table.Column<int>(type: "integer", nullable: false),
                    OwnerId = table.Column<long>(type: "bigint", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Vehicles", x => x.VehicleId);
                    table.ForeignKey(
                        name: "FK_Vehicles_Owners_OwnerId",
                        column: x => x.OwnerId,
                        principalTable: "Owners",
                        principalColumn: "OwnerId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Vehicles_VehicleClasses_VehicleClassId",
                        column: x => x.VehicleClassId,
                        principalTable: "VehicleClasses",
                        principalColumn: "VehicleClassId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Lanes",
                columns: table => new
                {
                    LaneId = table.Column<int>(type: "integer", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BoothId = table.Column<long>(type: "bigint", nullable: false),
                    LaneName = table.Column<string>(type: "text", nullable: true),
                    tollBoothBoothId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Lanes", x => x.LaneId);
                    table.ForeignKey(
                        name: "FK_Lanes_TollBooths_tollBoothBoothId",
                        column: x => x.tollBoothBoothId,
                        principalTable: "TollBooths",
                        principalColumn: "BoothId");
                });

            migrationBuilder.CreateTable(
                name: "TollRates",
                columns: table => new
                {
                    TollRateId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    BoothId = table.Column<long>(type: "bigint", nullable: false),
                    VehicleClassId = table.Column<int>(type: "integer", nullable: false),
                    TollAmount = table.Column<double>(type: "double precision", nullable: false),
                    EffectiveDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    tollBoothBoothId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TollRates", x => x.TollRateId);
                    table.ForeignKey(
                        name: "FK_TollRates_TollBooths_tollBoothBoothId",
                        column: x => x.tollBoothBoothId,
                        principalTable: "TollBooths",
                        principalColumn: "BoothId");
                    table.ForeignKey(
                        name: "FK_TollRates_VehicleClasses_VehicleClassId",
                        column: x => x.VehicleClassId,
                        principalTable: "VehicleClasses",
                        principalColumn: "VehicleClassId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FasttagRegisterations",
                columns: table => new
                {
                    FasttagRegisterationId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    VehicleId = table.Column<long>(type: "bigint", nullable: false),
                    FeedBack = table.Column<string>(type: "text", nullable: true),
                    Ratingid = table.Column<int>(type: "integer", nullable: false),
                    RegistrationTime = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    PaymentId = table.Column<long>(type: "bigint", nullable: false),
                    ValidDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    FastTagTypeid = table.Column<int>(type: "integer", nullable: false),
                    RegistrationStatus = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FasttagRegisterations", x => x.FasttagRegisterationId);
                    table.ForeignKey(
                        name: "FK_FasttagRegisterations_FastTagTypes_FastTagTypeid",
                        column: x => x.FastTagTypeid,
                        principalTable: "FastTagTypes",
                        principalColumn: "FastTagTypeid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FasttagRegisterations_Ratings_Ratingid",
                        column: x => x.Ratingid,
                        principalTable: "Ratings",
                        principalColumn: "Ratingid",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_FasttagRegisterations_Vehicles_VehicleId",
                        column: x => x.VehicleId,
                        principalTable: "Vehicles",
                        principalColumn: "VehicleId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tollfees",
                columns: table => new
                {
                    TollfeesId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    VehicleId = table.Column<long>(type: "bigint", nullable: false),
                    TollPlazzaOperatorId = table.Column<long>(type: "bigint", nullable: false),
                    LaneId = table.Column<int>(type: "integer", nullable: false),
                    IsAvailableFastTagId = table.Column<bool>(type: "boolean", nullable: false),
                    IsValidCard = table.Column<bool>(type: "boolean", nullable: false),
                    Amount = table.Column<double>(type: "double precision", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tollfees", x => x.TollfeesId);
                    table.ForeignKey(
                        name: "FK_Tollfees_Lanes_LaneId",
                        column: x => x.LaneId,
                        principalTable: "Lanes",
                        principalColumn: "LaneId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tollfees_TollPlazzaOperators_TollPlazzaOperatorId",
                        column: x => x.TollPlazzaOperatorId,
                        principalTable: "TollPlazzaOperators",
                        principalColumn: "TollPlazzaOperatorId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tollfees_Vehicles_VehicleId",
                        column: x => x.VehicleId,
                        principalTable: "Vehicles",
                        principalColumn: "VehicleId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FastTags",
                columns: table => new
                {
                    FastTagId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FasttagRegisterationId = table.Column<long>(type: "bigint", nullable: false),
                    ActivationStatus = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FastTags", x => x.FastTagId);
                    table.ForeignKey(
                        name: "FK_FastTags_FasttagRegisterations_FasttagRegisterationId",
                        column: x => x.FasttagRegisterationId,
                        principalTable: "FasttagRegisterations",
                        principalColumn: "FasttagRegisterationId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "FastTagPayments",
                columns: table => new
                {
                    PaymentId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    Amount = table.Column<double>(type: "double precision", nullable: false),
                    FastTagId = table.Column<long>(type: "bigint", nullable: false),
                    PaymentDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    PaymentMethod = table.Column<string>(type: "text", nullable: true),
                    TransactionId = table.Column<string>(type: "text", nullable: true),
                    IsSuccessful = table.Column<bool>(type: "boolean", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_FastTagPayments", x => x.PaymentId);
                    table.ForeignKey(
                        name: "FK_FastTagPayments_FastTags_FastTagId",
                        column: x => x.FastTagId,
                        principalTable: "FastTags",
                        principalColumn: "FastTagId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "RenewalCards",
                columns: table => new
                {
                    RenewalId = table.Column<long>(type: "bigint", nullable: false)
                        .Annotation("Npgsql:ValueGenerationStrategy", NpgsqlValueGenerationStrategy.IdentityByDefaultColumn),
                    FastTagId = table.Column<long>(type: "bigint", nullable: false),
                    RenewalDate = table.Column<DateTime>(type: "timestamp with time zone", nullable: false),
                    PaymentId = table.Column<long>(type: "bigint", nullable: false),
                    fastTagPaymentPaymentId = table.Column<long>(type: "bigint", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_RenewalCards", x => x.RenewalId);
                    table.ForeignKey(
                        name: "FK_RenewalCards_FastTagPayments_fastTagPaymentPaymentId",
                        column: x => x.fastTagPaymentPaymentId,
                        principalTable: "FastTagPayments",
                        principalColumn: "PaymentId");
                });

            migrationBuilder.CreateIndex(
                name: "IX_FastTagPayments_FastTagId",
                table: "FastTagPayments",
                column: "FastTagId");

            migrationBuilder.CreateIndex(
                name: "IX_FasttagRegisterations_FastTagTypeid",
                table: "FasttagRegisterations",
                column: "FastTagTypeid");

            migrationBuilder.CreateIndex(
                name: "IX_FasttagRegisterations_Ratingid",
                table: "FasttagRegisterations",
                column: "Ratingid");

            migrationBuilder.CreateIndex(
                name: "IX_FasttagRegisterations_VehicleId",
                table: "FasttagRegisterations",
                column: "VehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_FastTags_FasttagRegisterationId",
                table: "FastTags",
                column: "FasttagRegisterationId");

            migrationBuilder.CreateIndex(
                name: "IX_Lanes_tollBoothBoothId",
                table: "Lanes",
                column: "tollBoothBoothId");

            migrationBuilder.CreateIndex(
                name: "IX_RenewalCards_fastTagPaymentPaymentId",
                table: "RenewalCards",
                column: "fastTagPaymentPaymentId");

            migrationBuilder.CreateIndex(
                name: "IX_TollBooths_AdminId",
                table: "TollBooths",
                column: "AdminId");

            migrationBuilder.CreateIndex(
                name: "IX_Tollfees_LaneId",
                table: "Tollfees",
                column: "LaneId");

            migrationBuilder.CreateIndex(
                name: "IX_Tollfees_TollPlazzaOperatorId",
                table: "Tollfees",
                column: "TollPlazzaOperatorId");

            migrationBuilder.CreateIndex(
                name: "IX_Tollfees_VehicleId",
                table: "Tollfees",
                column: "VehicleId");

            migrationBuilder.CreateIndex(
                name: "IX_TollRates_tollBoothBoothId",
                table: "TollRates",
                column: "tollBoothBoothId");

            migrationBuilder.CreateIndex(
                name: "IX_TollRates_VehicleClassId",
                table: "TollRates",
                column: "VehicleClassId");

            migrationBuilder.CreateIndex(
                name: "IX_Vehicles_OwnerId",
                table: "Vehicles",
                column: "OwnerId",
                unique: true);

            migrationBuilder.CreateIndex(
                name: "IX_Vehicles_VehicleClassId",
                table: "Vehicles",
                column: "VehicleClassId");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "RenewalCards");

            migrationBuilder.DropTable(
                name: "Tollfees");

            migrationBuilder.DropTable(
                name: "TollRates");

            migrationBuilder.DropTable(
                name: "FastTagPayments");

            migrationBuilder.DropTable(
                name: "Lanes");

            migrationBuilder.DropTable(
                name: "TollPlazzaOperators");

            migrationBuilder.DropTable(
                name: "FastTags");

            migrationBuilder.DropTable(
                name: "TollBooths");

            migrationBuilder.DropTable(
                name: "FasttagRegisterations");

            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "FastTagTypes");

            migrationBuilder.DropTable(
                name: "Ratings");

            migrationBuilder.DropTable(
                name: "Vehicles");

            migrationBuilder.DropTable(
                name: "Owners");

            migrationBuilder.DropTable(
                name: "VehicleClasses");
        }
    }
}
