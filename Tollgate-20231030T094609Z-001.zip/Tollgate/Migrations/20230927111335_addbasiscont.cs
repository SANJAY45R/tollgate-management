﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tollgate.Migrations
{
    /// <inheritdoc />
    public partial class Addbasiscont : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FastTagTypes_Basis_BasisId",
                table: "FastTagTypes");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Basis",
                table: "Basis");

            migrationBuilder.RenameTable(
                name: "Basis",
                newName: "Bases");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Bases",
                table: "Bases",
                column: "BasisId");

            migrationBuilder.AddForeignKey(
                name: "FK_FastTagTypes_Bases_BasisId",
                table: "FastTagTypes",
                column: "BasisId",
                principalTable: "Bases",
                principalColumn: "BasisId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FastTagTypes_Bases_BasisId",
                table: "FastTagTypes");

            migrationBuilder.DropPrimaryKey(
                name: "PK_Bases",
                table: "Bases");

            migrationBuilder.RenameTable(
                name: "Bases",
                newName: "Basis");

            migrationBuilder.AddPrimaryKey(
                name: "PK_Basis",
                table: "Basis",
                column: "BasisId");

            migrationBuilder.AddForeignKey(
                name: "FK_FastTagTypes_Basis_BasisId",
                table: "FastTagTypes",
                column: "BasisId",
                principalTable: "Basis",
                principalColumn: "BasisId",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
