﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tollgate.Migrations
{
    /// <inheritdoc />
    public partial class Amountforfasttype : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<double>(
                name: "Amount",
                table: "FastTagTypes",
                type: "double precision",
                nullable: false,
                defaultValue: 0.0);

            migrationBuilder.CreateIndex(
                name: "IX_FasttagRegisterations_PaymentId",
                table: "FasttagRegisterations",
                column: "PaymentId",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_FasttagRegisterations_FastTagPayments_PaymentId",
                table: "FasttagRegisterations",
                column: "PaymentId",
                principalTable: "FastTagPayments",
                principalColumn: "PaymentId",
                onDelete: ReferentialAction.Cascade);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FasttagRegisterations_FastTagPayments_PaymentId",
                table: "FasttagRegisterations");

            migrationBuilder.DropIndex(
                name: "IX_FasttagRegisterations_PaymentId",
                table: "FasttagRegisterations");

            migrationBuilder.DropColumn(
                name: "Amount",
                table: "FastTagTypes");
        }
    }
}
