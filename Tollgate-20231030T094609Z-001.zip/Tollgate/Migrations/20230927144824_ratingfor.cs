﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Tollgate.Migrations
{
    /// <inheritdoc />
    public partial class Ratingfor : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_FasttagRegisterations_Ratings_Ratingid",
                table: "FasttagRegisterations");

            migrationBuilder.DropIndex(
                name: "IX_FasttagRegisterations_Ratingid",
                table: "FasttagRegisterations");

            migrationBuilder.DropColumn(
                name: "Ratingid",
                table: "FasttagRegisterations");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<int>(
                name: "Ratingid",
                table: "FasttagRegisterations",
                type: "integer",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_FasttagRegisterations_Ratingid",
                table: "FasttagRegisterations",
                column: "Ratingid");

            migrationBuilder.AddForeignKey(
                name: "FK_FasttagRegisterations_Ratings_Ratingid",
                table: "FasttagRegisterations",
                column: "Ratingid",
                principalTable: "Ratings",
                principalColumn: "Ratingid");
        }
    }
}
