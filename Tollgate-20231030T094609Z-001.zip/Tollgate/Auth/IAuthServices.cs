namespace Tollgate.Auth;
public interface IAuthServices {
    public string GenerateToken(long id,string name);
}