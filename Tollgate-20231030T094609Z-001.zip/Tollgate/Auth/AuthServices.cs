using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using Microsoft.IdentityModel.Tokens;
using Tollgate.Auth;
#nullable disable
namespace Tollgate.Jwt
{
    public class AuthServices : IAuthServices
    { 
        private readonly IConfiguration _configuration;

        public AuthServices(IConfiguration configuration)
        {
            _configuration = configuration;
        }
        public string GenerateToken(long id,string name)
        {

            var claims = new[]{
            new Claim(ClaimTypes.NameIdentifier,id.ToString()),
            new Claim(ClaimTypes.Role,name.ToString())
        };

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration.GetSection("Jwt:JwtSecretKey").Value));
            var credential = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var newtoken = new JwtSecurityToken(
                issuer: _configuration.GetSection("Jwt:Issuer").Value,
                audience: _configuration.GetSection("Jwt:Audience").Value,
                claims: claims,
                expires: DateTime.Now.AddHours(Convert.ToDouble(_configuration.GetSection("Jwt:Time").Value)),
                signingCredentials: credential
            );

            return new JwtSecurityTokenHandler().WriteToken(newtoken);

        }

    }
}