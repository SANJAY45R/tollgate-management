
using AutoMapper;
using Tollgate.context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml;
using Tollgate.Dto;
using Tollgate.Models;
using Microsoft.AspNetCore.Authorization;
#nullable disable

namespace Tollgate.Controllers;
[ApiController]
[Route("api/[controller]")]
public class TollPlazzaoperatorController : ControllerBase
{
    private TollgateContext _context;
    private IMapper _mapper;
    public TollPlazzaoperatorController(TollgateContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }



    [HttpPost]
    public async Task<IActionResult> CreateOperator(TollPlazzaOperatorDto tollPlazzaOperatorDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest();
        }

        var ad = _mapper.Map<TollPlazzaOperatorDto, TollPlazzaOperator>(tollPlazzaOperatorDto);
        await _context.TollPlazzaOperators.AddAsync(ad);
        await _context.SaveChangesAsync();
        return Ok(new
        {
            Status = "Sucess",
            Message = "operator Created Sucessfully",
            Data = ad
        });
    }
    [HttpGet]
    public async Task<IActionResult> Getall()
    {
        var adminlist = await _context.TollPlazzaOperators.ToListAsync();
        if (adminlist.Count == 0)
        {
            return Ok(new
            {
                Status = "Failed",
                Message = "Not Found",
                Data = adminlist
            });

        }
        return Ok(new
        {
            Status = "Sucess",
            Message = "Retrieve TollPlazzaoperatordetails Sucessfully",
            Data = adminlist
        });
    }

    [HttpGet("pagewisedetails")]
    public async Task<IActionResult> Getalloperatorswithpagewise([FromQuery] int PageNumber, [FromQuery] int PagewiseData)
    {
        if (PageNumber <= 0 || PagewiseData <= 0)
        {
            return BadRequest(new
            {
                Status = "Failed",
                Message = "Invalid Request ..pagenumber and pagewisedata should be greater than 0",
            });
        }
        int skip = (PageNumber - 1) * PagewiseData;

        var oper = await _context.TollPlazzaOperators
        .Skip(skip)
        .Take(PagewiseData)
        .ToListAsync();
        int total = await _context.TollPlazzaOperators.CountAsync();

        var pagination = new PaginationModel<TollPlazzaOperator>
        {
            PageNumber = PageNumber,
            PagewiseData = PagewiseData,
            TotalNumberOfData = total,
            Data = oper

        };
        return Ok(new
        {
            Status = "Sucess",
            Message = "PageNumer wise data retrieved",
            Data = pagination
        });

    }

    [HttpGet("GetbyId")]
    public async Task<IActionResult> Getbyid(long Id)
    {
        var adminlist = await _context.TollPlazzaOperators.FindAsync(Id);
        if (adminlist == null)
        {
            return Ok(new
            {
                Status = "Failed",
                Message = "Notfound TollPlazzaoperator details",
                Data = adminlist
            });

        }
        return Ok(new
        {
            Status = "Sucess",
            Message = "Retrieve TollPlazzaoperator detail Sucessfully",
            Data = adminlist
        });
    }
    [Authorize(Roles = "Admin")]
    [HttpPost("ImportCategoriesFromExcel")]
    public async Task<IActionResult> ImportCategoriesFromExcel(IFormFile excelFile)
    {
        try
        {
            if (excelFile == null || excelFile.Length == 0)
            {
                return BadRequest("Invalid file");
            }

            using (var package = new ExcelPackage(excelFile.OpenReadStream()))
            {
                var worksheet = package.Workbook.Worksheets.FirstOrDefault();
                if (worksheet == null)
                {
                    return BadRequest("No worksheet found in the Excel file.");
                }

                var rowCount = worksheet.Dimension.Rows;

                for (int row = 2; row <= rowCount; row++) // Assuming the header is in the first row
                {
                    var tollPlazzaOperatorDto = new TollPlazzaOperatorDto
                    {
                        UserName = worksheet.Cells[row, 1].Value?.ToString(),
                        Password = worksheet.Cells[row, 2].Value?.ToString(),
                        Role = worksheet.Cells[row, 3].Value?.ToString(),
                        Address = worksheet.Cells[row, 4].Value?.ToString(),
                        PhoneNumber = worksheet.Cells[row, 5].Value?.ToString(),
                        Email = worksheet.Cells[row, 6].Value?.ToString(),
                        FirstName = worksheet.Cells[row, 7].Value?.ToString(),
                        LastName = worksheet.Cells[row, 8].GetCellValue<char>(),
                        IsDeleted = false, // Assuming it's not deleted by default

                    };

                    // You can add validation logic here before creating the category

                    // Invoke the CreateCategory method for each categoryDto
                    await CreateOperator(tollPlazzaOperatorDto);

                }

                return Ok(new { Status = "Success", Message = "TollPlazzaoperators imported successfully" });
            }
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }

    [HttpGet("operatorsCount")]
    public async Task<IActionResult> GetTollPlazaOperatorCount()
    {
        try
        {
            var operatorCount = await _context.TollPlazzaOperators.CountAsync();

            return Ok(new
            {
                Status = "Success",
                Message = "Total number of Toll Plaza Operators",
                Data = operatorCount
            });
        }
        catch (Exception ex)
        {
            return StatusCode(500, $"Internal server error: {ex.Message}");
        }
    }




}
