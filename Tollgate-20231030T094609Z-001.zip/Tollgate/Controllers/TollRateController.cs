using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TollRateController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public TollRateController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateTollRate(TollRateDto tollRateDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var tollRate = _mapper.Map<TollRateDto, TollRate>(tollRateDto);

                // Additional logic can be added here, such as validation or data processing

                await _context.TollRates.AddAsync(tollRate);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetTollRateById), new { id = tollRate.TollRateId }, tollRate);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllTollRates()
        {
            try
            {
                var tollRates = await _context.TollRates.ToListAsync();
                if (tollRates.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Toll Rates Found",
                        Data = tollRates
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Rates Successfully",
                    Data = tollRates
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTollRateById(long id)
        {
            try
            {
                var tollRate = await _context.TollRates.FindAsync(id);
                if (tollRate == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Rate Not Found",
                        Data = tollRate
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Rate Successfully",
                    Data = tollRate
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTollRate(long id, TollRateDto tollRateDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingTollRate = await _context.TollRates.FindAsync(id);
                if (existingTollRate == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Rate Not Found",
                        Data = existingTollRate
                    });
                }

                _mapper.Map(tollRateDto, existingTollRate);

                // Additional logic can be added here, such as validation or data processing

                _context.TollRates.Update(existingTollRate);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Toll Rate Updated Successfully",
                    Data = existingTollRate
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        
    }
}
