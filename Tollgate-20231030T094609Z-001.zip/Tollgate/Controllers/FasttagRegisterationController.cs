using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;
#nullable disable
namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FasttagRegistrationController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public FasttagRegistrationController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllFasttagRegistrations()
        {
            try
            {
                var registrations = await _context.FasttagRegisterations.ToListAsync();
                if (registrations.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Fasttag Registrations Found",
                        Data = registrations
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Fasttag Registrations Successfully",
                    Data = registrations
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetFasttagRegistrationById(long id)
        {
            try
            {
                var registration = await _context.FasttagRegisterations.FindAsync(id);
                if (registration == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Fasttag Registration Not Found",
                        Data = registration
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Fasttag Registration Successfully",
                    Data = registration
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFasttagRegistration(long id, FasttagRegisterationDto fasttagRegistrationDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingRegistration = await _context.FasttagRegisterations.FindAsync(id);
                if (existingRegistration == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Fasttag Registration Not Found",
                        Data = existingRegistration
                    });
                }

                _mapper.Map(fasttagRegistrationDto, existingRegistration);

                // Additional logic can be added here, such as validation or data processing

                _context.FasttagRegisterations.Update(existingRegistration);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Fasttag Registration Updated Successfully",
                    Data = existingRegistration
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPost("Register")]
        public async Task<IActionResult> RegisterFastTag(FasttagRegisterationDto registrationDto)
        {
            try
            {
                DateTime validDate;

                switch (registrationDto.FastTagTypeid)
                {
                    case 1:
                        validDate = DateTime.UtcNow.AddMonths(1);
                        break;
                    case 2:
                        validDate = DateTime.UtcNow.AddDays(1);
                        break;
                    case 3:
                        validDate = DateTime.UtcNow.AddYears(1);
                        break;
                    case 4:
                        validDate = DateTime.UtcNow.AddMonths(1);
                        break;
                    case 5:
                        validDate = DateTime.UtcNow.AddDays(1);
                        break;
                    case 6:
                        validDate = DateTime.UtcNow.AddYears(1);
                        break;
                    default:
                        return Ok(new
                        {
                            Status = "Failed",
                            Message = "Enter a valid Fasttagtype id"
                        });
                }

                var fastTag = new FasttagRegisteration
                {
                    VehicleId = registrationDto.VehicleId,
                    FastTagTypeid = registrationDto.FastTagTypeid,
                    RegistrationTime = DateTime.UtcNow,
                    ValidDate = validDate,
                    RegistrationStatus = true,
                };

                var find = await _context.FastTagTypes.FirstOrDefaultAsync(o => o.FastTagTypeid == fastTag.FastTagTypeid);
                fastTag.TotalAmount = find.Amount;

                _context.FasttagRegisterations.Add(fastTag);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Registration completed",
                    Data = fastTag,
                    PayAmount = find?.Amount // Use the null conditional operator to prevent null reference errors
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("SuccessfulRegistrationsCount")]
        public async Task<IActionResult> GetSuccessfulRegistrationsCount()
        {
            try
            {
                // Count the number of Fasttag registrations with a successful status
                var successfulRegistrationsCount = await _context.FasttagRegisterations
                    .Where(r => r.RegistrationStatus == true) // Assuming "true" indicates a successful registration
                    .CountAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Number of successful Fasttag registrations",
                    Data = successfulRegistrationsCount
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }





    }
}
