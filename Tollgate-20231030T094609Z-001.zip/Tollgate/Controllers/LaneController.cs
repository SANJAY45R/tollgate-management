using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LaneController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public LaneController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateLane(LaneDto laneDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var lane = _mapper.Map<LaneDto, Lane>(laneDto);

                // Additional logic can be added here, such as validation or data processing

                await _context.Lanes.AddAsync(lane);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetLaneById), new { id = lane.LaneId }, lane);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllLanes()
        {
            try
            {
                var lanes = await _context.Lanes.ToListAsync();
                if (lanes.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Lanes Found",
                        Data = lanes
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Lanes Successfully",
                    Data = lanes
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetLaneById(long id)
        {
            try
            {
                var lane = await _context.Lanes.FindAsync(id);
                if (lane == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Lane Not Found",
                        Data = lane
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Lane Successfully",
                    Data = lane
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateLane(long id, LaneDto laneDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingLane = await _context.Lanes.FindAsync(id);
                if (existingLane == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Lane Not Found",
                        Data = existingLane
                    });
                }

                _mapper.Map(laneDto, existingLane);

                // Additional logic can be added here, such as validation or data processing

                _context.Lanes.Update(existingLane);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Lane Updated Successfully",
                    Data = existingLane
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("booth-lane-details")]
        public async Task<IActionResult> GetBoothLaneDetails()
        {
            try
            {
                var boothDetails = await _context.TollBooths
                    .Include(tb => tb.lanes) // Include related Lanes if you have a navigation property
                    .ToListAsync();

                if (boothDetails.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Booth Details Found",
                        Data = boothDetails
                    });
                }

                // Calculate the number of lanes for each booth and find the booth with the highest number of lanes
                var boothLaneCounts = boothDetails
                    .Select(tb => new
                    {
                        BoothId = tb.BoothId,
                        // LaneName = tb.LaneName, // Replace with the actual property name
                        NumberOfLanes = tb.lanes.Count
                    })
                    .ToList();

                var maxLanes = boothLaneCounts.Max(blc => blc.NumberOfLanes);
                var boothWithMaxLanes = boothLaneCounts.FirstOrDefault(blc => blc.NumberOfLanes == maxLanes);

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Booth Lane Details Successfully",
                    Data = boothLaneCounts,
                    BoothWithMaxLanes = boothWithMaxLanes
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("booth-lane-numbersdetails")]
        public async Task<IActionResult> GetNumberofBoothLaneDetails()
        {
            try
            {
                var boothDetails = await _context.TollBooths
                    .Include(tb => tb.lanes) // Include related Lanes if you have a navigation property
                    .ToListAsync();

                if (boothDetails.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Booth Details Found",
                        Data = boothDetails
                    });
                }

                // Calculate the number of lanes for each booth and find the booth with the highest number of lanes
                var boothLaneCounts = boothDetails
                    .Select(tb => new
                    {
                        BoothId = tb.BoothId,
                        // BoothName = tb.BoothName, // Replace with the actual property name for booth name
                        NumberOfLanes = tb.lanes.Count
                    })
                    .ToList();

                var maxLanes = boothLaneCounts.Max(blc => blc.NumberOfLanes);
                var boothWithMaxLanes = boothLaneCounts.FirstOrDefault(blc => blc.NumberOfLanes == maxLanes);

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Booth Lane Details Successfully",
                    Data = boothLaneCounts,
                    BoothWithMaxLanes = boothWithMaxLanes
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }




    }
}
