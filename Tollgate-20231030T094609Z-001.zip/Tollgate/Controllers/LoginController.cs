using Tollgate.context;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.Auth;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class LoginController:ControllerBase
    {
        private IAuthServices _services;

        private TollgateContext _context;
        public LoginController(TollgateContext context,IAuthServices services)
        {
            _context = context;
            _services =services;
        }
     
        [HttpPost("AdminLogin")]
        public async Task<IActionResult>AdminLogin(AdminLoginDto userLoginDto)
        {
            var admin = await _context.Admins.FirstOrDefaultAsync(o=>o.AdminName == userLoginDto.AdminName);
            if(admin == null)
            {
                return NotFound();
            }
            string hash = BCrypt.Net.BCrypt.HashPassword(userLoginDto.Password);
            if(admin.Password == hash)
            {
                var token = _services.GenerateToken(admin.AdminId , admin.Role);
                return Ok(new{
                    Status = "Sucess",
                    Message= "Admin Login Sucessfull",
                    Data = new{
                        admin,
                        token
                    }
                });
            }
             return BadRequest(new{
                    Status = "Failed",
                    Message= "Admin Not found",
                    Data = admin
                });
        }
        [HttpPost("TollPlazzaOperatorLogin")]
        public async Task<IActionResult>OperatorLogin(TollPlazzaOperatorLoginDto userLoginDto)
        {
            var oper = await _context.TollPlazzaOperators.FirstOrDefaultAsync(o=>o.UserName == userLoginDto.UserName);
            if(oper == null)
            {
                return NotFound();
            }
            if(oper.Password == userLoginDto.Password)
            {
                var token = _services.GenerateToken(oper.TollPlazzaOperatorId , oper.Role);
                return Ok(new{
                    Status = "Sucess",
                    Message= "TollPlazza operator Login Sucessfull",
                    Data = new{
                        oper,
                        token
                    }
                });
            }
             return BadRequest(new{
                    Status = "Failed",
                    Message= "TollPlazza operator Not found",
                    Data = oper
                });
        }
        [HttpPost("OwnerLogin")]
        public async Task<IActionResult>OwnerLogin(OwnerLoginDto userLoginDto)
        {
            var own = await _context.Owners.FirstOrDefaultAsync(o=>o.OwnerName == userLoginDto.OwnerName);
            if(own == null)
            {
                return NotFound();
            }
            if(own.Password == userLoginDto.Password)
            {
                var token = _services.GenerateToken(own.OwnerId , own.Role);
                return Ok(new{
                    Status = "Sucess",
                    Message= "Owner Login Sucessfull",
                    Data = new{
                        own,
                        token
                    }
                });
            }
             return BadRequest(new{
                    Status = "Failed",
                    Message= "Owner Not found",
                    Data = own
                });
        }

        
    }
}