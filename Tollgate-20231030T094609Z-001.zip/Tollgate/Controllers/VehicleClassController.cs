
using AutoMapper;
using Tollgate.context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.Dto;
using Tollgate.Models;


namespace Tollgate.Controllers
{
    [ApiController]
    [Route("/api[Controller]")]
    public class VehicleClassController : ControllerBase
    {
        private TollgateContext _context;
        private IMapper _mapper;

        public VehicleClassController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> Getall()
        {
            var vehi= await _context.VehicleClasses.ToListAsync();
            if (vehi.Count == 0)
            {
                return Ok(new
                {
                    Status = "Failed",
                    Message = "Notfound vehicleclass details",
                    Data = vehi
                });
            }

            return Ok(new
            {
                Status = "Sucess",
                Message = "Retrieve vehicleclass detail Sucessfully",
                Data = vehi
            });
        }
        [HttpGet("Getbyid")]
         public async Task<IActionResult> Getbyid(long id)
        {
            var vehic = await _context.VehicleClasses.FindAsync(id);
            if (vehic == null)
            {
                return Ok(new
                {
                    Status = "Failed",
                    Message = "Notfound vehicleclass details",
                    Data = vehic
                });
            }

            return Ok(new
            {
                Status = "Sucess",
                Message = "Retrieve vehicleclass details get by id  Sucessfully",
                Data = vehic
            });
        }
        [HttpPost]
         public async Task<IActionResult> CreateOwner(VehicleClassDto vehicleClassDto)
        {
            if(!ModelState.IsValid)
            {
                return BadRequest();
            }
            
            var vehic = _mapper.Map<VehicleClassDto,VehicleClass>(vehicleClassDto);
            await _context.VehicleClasses.AddAsync(vehic);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Status = "Sucess",
                Message = "Created vehicleclass Sucessfully",
                Data = vehic
            });
        }



    }
}
        
