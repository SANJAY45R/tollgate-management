using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class BasisController : ControllerBase
    {
        private readonly TollgateContext _context;
        

        public BasisController(TollgateContext context)
        {
            _context = context;
            
        }

        [HttpPost]
        public async Task<IActionResult> CreateRating(BasisDto ratingDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                    var rating = new Basis{
                        BasisName = ratingDto.BasisName
                    };
               

                // Additional logic can be added here, srauch as validation or data processing

                await _context.Bases.AddAsync(rating);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetRatingById), new { id = rating.BasisId }, rating);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllRatings()
        {
            try
            {
                var ratings = await _context.Bases.ToListAsync();
                if (ratings.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Basis Found",
                        Data = ratings
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Basis Successfully",
                    Data = ratings
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetRatingById(int id)
        {
            try
            {
                var rating = await _context.Bases.FindAsync(id);
                if (rating == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Basis Not Found",
                        Data = rating
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Basis Successfully",
                    Data = rating
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRating(int id, BasisDto ratingDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingRating = await _context.Bases.FindAsync(id);
                if (existingRating == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Rating Not Found",
                        Data = existingRating
                    });
                }

                existingRating.BasisName = ratingDto.BasisName;

                // Additional logic can be added here, such as validation or data processing

                _context.Bases.Update(existingRating);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Basis Updated Successfully",
                    Data = existingRating
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

       
    }
}
