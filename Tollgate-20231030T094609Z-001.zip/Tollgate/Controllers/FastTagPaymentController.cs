using System;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;
#nullable disable
namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FastTagPaymentController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public FastTagPaymentController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateFastTagPayment(FastTagPaymentDto fastTagPaymentDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var payment = _mapper.Map<FastTagPaymentDto, FastTagPayment>(fastTagPaymentDto);


                await _context.FastTagPayments.AddAsync(payment);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetFastTagPaymentById), new { id = payment.PaymentId }, payment);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllFastTagPayments()
        {
            try
            {
                var payments = await _context.FastTagPayments.ToListAsync();
                if (payments.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No FastTag Payments Found",
                        Data = payments
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve FastTag Payments Successfully",
                    Data = payments
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetFastTagPaymentById(long id)
        {
            try
            {
                var payment = await _context.FastTagPayments.FindAsync(id);
                if (payment == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "FastTag Payment Not Found",
                        Data = payment
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve FastTag Payment Successfully",
                    Data = payment
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFastTagPayment(long id, FastTagPaymentDto fastTagPaymentDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingPayment = await _context.FastTagPayments.FindAsync(id);
                if (existingPayment == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "FastTag Payment Not Found",
                        Data = existingPayment
                    });
                }

                _mapper.Map(fastTagPaymentDto, existingPayment);

                // Additional logic can be added here, such as validation or data processing

                _context.FastTagPayments.Update(existingPayment);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "FastTag Payment Updated Successfully",
                    Data = existingPayment
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        
        [HttpPost("Paymentforfasttag")]
        public async Task<IActionResult> Paymentforregister(FastTagPaymentDto fastTagPaymentDto)
        {
            var check = await _context.FasttagRegisterations.FindAsync(fastTagPaymentDto.FastTagId);
            if (check == null)
            {
                return BadRequest("Invalid FastTagId");
            }

        
            if (check.VehicleId == null)
            {
                return BadRequest("VehicleId is null");
            }

           



         
            string GenerateTransactionId()
            {
                string timestamp = DateTime.UtcNow.ToString("yyyyMMddHHmmssfff");
                Random random = new Random();
                int randomNumber = random.Next(1000, 10000);
                return $"{timestamp}{randomNumber}";
            }


            var payment = new FastTagPayment
            {
                FastTagId = fastTagPaymentDto.FastTagId,
                PaymentMethod = fastTagPaymentDto.PaymentMethod,
                Amount = fastTagPaymentDto.Amount,

            };

            // Check if the payment amount matches the FastTagType amount
            if (check.TotalAmount == payment.Amount)
            {
                payment.IsSuccessful = true;
                payment.TransactionId = GenerateTransactionId();
                payment.PaymentDate = DateTime.UtcNow;
                payment.IsValid = true;
            }
            else
            {
                return BadRequest("Payment amount does not match FastTagType amount");
            }

            await _context.FastTagPayments.AddAsync(payment);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Status = "Success",
                Message = "Payment Successful",
                Data = payment
            });
        }

        [HttpGet("TotalAmount")]
        public async Task<IActionResult> GetTotalAmount()
        {
            try
            {
                var totalAmount = await _context.FastTagPayments.SumAsync(payment => payment.Amount);

                return Ok(new
                {
                    Status = "Success",
                    Message = "Total FastTag Payment Amount",
                    Data = totalAmount
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("MonthlyTotalAmount")]
        public async Task<IActionResult> GetMonthlyTotalAmount()
        {
            try
            {
                var monthlyTotalAmounts = await _context.FastTagPayments
                    .GroupBy(payment => new { payment.PaymentDate.Year, payment.PaymentDate.Month })
                    .Select(group => new
                    {
                        Year = group.Key.Year,
                        Month = group.Key.Month,
                        TotalAmount = group.Sum(payment => payment.Amount)
                    })
                    .ToListAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Monthly Total Payment Amounts",
                    Data = monthlyTotalAmounts
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("GeneratePaymentReport")]
        public async Task<IActionResult> GeneratePaymentReport([FromQuery] string startDateString, [FromQuery] string endDateString)
        {
            DateTime parseddate;
            DateTime parseddate1;
            // Parse the date strings into DateTime objects
            if (!DateTime.TryParseExact(startDateString, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out parseddate) ||
                !DateTime.TryParseExact(endDateString, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out parseddate1))
            {
                return BadRequest("Invalid date format. Please use 'dd/mm/yyyy' format.");
            }
            parseddate = parseddate.ToUniversalTime();
            parseddate1 = parseddate1.ToUniversalTime();


            var paymentTransactions = await _context.FastTagPayments
                .Where(p => p.PaymentDate >= parseddate && p.PaymentDate <= parseddate1)
                .Select(p => new FastTagPayment
                {
                    PaymentId = p.PaymentId,
                    PaymentDate = p.PaymentDate,
                    Amount = p.Amount,
                    TransactionId = p.TransactionId,
                    IsSuccessful = p.IsSuccessful,

                    // Map other properties as needed
                })
                .ToListAsync();

            // Return the payment transactions as a report
            return Ok(new
            {
                Paymentdetails = paymentTransactions
            });
        }
        [HttpGet("GeneratePaymentReportdatewise")]
        public async Task<IActionResult> GeneratePaymentReportDatewise([FromQuery] string startDateString)
        {
            DateTime parseddate;

            // Parse the date strings into DateTime objects
            if (!DateTime.TryParseExact(startDateString, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out parseddate))
            {
                return BadRequest("Invalid date format. Please use 'dd/mm/yyyy' format.");
            }
            parseddate = parseddate.ToUniversalTime();



            var paymentTransactions = await _context.FastTagPayments
                .Where(p => p.PaymentDate >= parseddate)
                .Select(p => new FastTagPayment
                {
                    PaymentId = p.PaymentId,
                    PaymentDate = p.PaymentDate,
                    Amount = p.Amount,
                    TransactionId = p.TransactionId,
                    IsSuccessful = p.IsSuccessful,


                })
                .ToListAsync();
            return Ok(new
            {
                Paymentdetails = paymentTransactions
            });
        }





    }
}
