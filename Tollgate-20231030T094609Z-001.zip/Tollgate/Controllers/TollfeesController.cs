using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;
#nullable disable

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TollfeesController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public TollfeesController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateTollfees(TollfeesDto tollfeesDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var tollfees = _mapper.Map<TollfeesDto, Tollfees>(tollfeesDto);

                // Additional logic can be added here, such as validation or data processing

                await _context.Tollfees.AddAsync(tollfees);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetTollfeesById), new { id = tollfees.TollfeesId }, tollfees);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllTollfees()
        {
            try
            {
                var tollfees = await _context.Tollfees.ToListAsync();
                if (tollfees.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Toll Fees Found",
                        Data = tollfees
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Fees Successfully",
                    Data = tollfees
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTollfeesById(long id)
        {
            try
            {
                var tollfees = await _context.Tollfees.FindAsync(id);
                if (tollfees == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Fees Not Found",
                        Data = tollfees
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Fees Successfully",
                    Data = tollfees
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTollfees(long id, TollfeesDto tollfeesDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingTollfees = await _context.Tollfees.FindAsync(id);
                if (existingTollfees == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Fees Not Found",
                        Data = existingTollfees
                    });
                }

                _mapper.Map(tollfeesDto, existingTollfees);

                // Additional logic can be added here, such as validation or data processing

                _context.Tollfees.Update(existingTollfees);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Toll Fees Updated Successfully",
                    Data = existingTollfees
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpPost("Tollfees")]
        public async Task<IActionResult> CreateTollfeesmanually(TollfeesDto tollfeesDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                // Check if the vehicle has a valid FastTag
                var vehicleId = tollfeesDto.VehicleClassId;
                var validFastTag = await _context.FasttagRegisterations
                    .FirstOrDefaultAsync(fastTag => fastTag.VehicleId == vehicleId && fastTag.ValidDate >= DateTime.UtcNow);

                double amount;

                if (validFastTag != null)
                {

                    amount = 0;
                }
                else
                {

                    var tollRate = await _context.TollRates
                        .FirstOrDefaultAsync(rate => rate.VehicleClassId == tollfeesDto.VehicleClassId);

                    if (tollRate != null)
                    {
                        amount = tollRate.TollAmount;
                    }
                    else
                    {
                        return NotFound(new
                        {
                            Status = "Failed",
                            Message = "Toll Rate Not Found",
                            Data = tollfeesDto
                        });
                    }
                }

                var tollfees = new Tollfees
                {
                    VehicleClassId = tollfeesDto.VehicleClassId,
                    VehicleId = tollfeesDto.vehicleId,
                    TollPlazzaOperatorId = tollfeesDto.TollPlazzaOperatorId,
                    LaneId = tollfeesDto.LaneId,
                    IsAvailableFastTagId = validFastTag != null,
                    IsValidCard = validFastTag != null,
                    Amount = amount
                };

                // Additional logic can be added here, such as validation or data processing

                await _context.Tollfees.AddAsync(tollfees);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetTollfeesById), new { id = tollfees.TollfeesId }, tollfees);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("OperatorsTotalEarnings")]
        public async Task<IActionResult> GetOperatorsTotalEarnings()
        {
            try
            {
                var operatorEarnings = await _context.Tollfees
                    .GroupBy(tf => tf.TollPlazzaOperatorId)
                    .Select(group => new
                    {
                        OperatorId = group.Key,
                        OperatorName = group.FirstOrDefault().tollPlazzaOperator.UserName, // Assuming you have a navigation property named "TollPlazzaOperator"
                        TotalAmountEarned = group.Sum(tf => tf.Amount)
                    })
                    .ToListAsync();

                if (operatorEarnings.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Operator Earnings Found",
                        Data = operatorEarnings
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Operator Earnings Successfully",
                    Data = operatorEarnings
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        




    }
}
