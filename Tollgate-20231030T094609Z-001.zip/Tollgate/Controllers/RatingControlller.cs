using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RatingController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public RatingController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateRating(RatingDto ratingDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var rating = _mapper.Map<RatingDto, Rating>(ratingDto);

                // Additional logic can be added here, such as validation or data processing

                await _context.Ratings.AddAsync(rating);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetRatingById), new { id = rating.Ratingid }, rating);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllRatings()
        {
            try
            {
                var ratings = await _context.Ratings.ToListAsync();
                if (ratings.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Ratings Found",
                        Data = ratings
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Ratings Successfully",
                    Data = ratings
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetRatingById(long id)
        {
            try
            {
                var rating = await _context.Ratings.FindAsync(id);
                if (rating == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Rating Not Found",
                        Data = rating
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Rating Successfully",
                    Data = rating
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRating(long id, RatingDto ratingDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingRating = await _context.Ratings.FindAsync(id);
                if (existingRating == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Rating Not Found",
                        Data = existingRating
                    });
                }

                _mapper.Map(ratingDto, existingRating);

                // Additional logic can be added here, such as validation or data processing

                _context.Ratings.Update(existingRating);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Rating Updated Successfully",
                    Data = existingRating
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

       
    }
}
