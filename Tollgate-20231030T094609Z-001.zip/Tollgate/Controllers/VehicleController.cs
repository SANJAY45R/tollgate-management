
using AutoMapper;
using Tollgate.context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.Dto;
using Tollgate.Models;


namespace Tollgate.Controllers
{
    [ApiController]
    [Route("/api[Controller]")]
    public class VehicleController : ControllerBase
    {
        private TollgateContext _context;
        private IMapper _mapper;

        public VehicleController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }
        [HttpGet]
        public async Task<IActionResult> Getall()
        {
            var vehi = await _context.Vehicles.ToListAsync();
            if (vehi.Count == 0)
            {
                return Ok(new
                {
                    Status = "Failed",
                    Message = "Notfound vehicle details",
                    Data = vehi
                });
            }

            return Ok(new
            {
                Status = "Sucess",
                Message = "Retrieve vehicle detail Sucessfully",
                Data = vehi
            });
        }
        [HttpGet("Getbyid")]
        public async Task<IActionResult> Getbyid(long id)
        {
            var vehic = await _context.Vehicles.FindAsync(id);
            if (vehic == null)
            {
                return Ok(new
                {
                    Status = "Failed",
                    Message = "Notfound vehicle details",
                    Data = vehic
                });
            }

            return Ok(new
            {
                Status = "Sucess",
                Message = "Retrieve vehicle details get by id  Sucessfully",
                Data = vehic
            });
        }
        [HttpPost]
        public async Task<IActionResult> CreateOwner(VehicleDto vehicleDto)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest();
            }

            var vehic = _mapper.Map<VehicleDto, Vehicle>(vehicleDto);
            await _context.Vehicles.AddAsync(vehic);
            await _context.SaveChangesAsync();

            return Ok(new
            {
                Status = "Sucess",
                Message = "Created vehicle Sucessfully",
                Data = vehic
            });
        }

        [HttpGet("GetAllVehiclesWithOwners")]
        public async Task<IActionResult> GetAllVehiclesWithOwners()
        {
            try
            {
                var vehiclesWithOwners = await _context.Vehicles.Include(v => v.owner).ToListAsync();
                if (vehiclesWithOwners.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Vehicles Found",
                        Data = vehiclesWithOwners
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Vehicle Details with Owners Successfully",
                    Data = vehiclesWithOwners
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }




    }
}

