using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class TollBoothController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public TollBoothController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateTollBooth(TollBoothDto tollBoothDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var tollBooth = _mapper.Map<TollBoothDto, TollBooth>(tollBoothDto);

                // Additional logic can be added here, such as validation or data processing

                await _context.TollBooths.AddAsync(tollBooth);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetTollBoothById), new { id = tollBooth.BoothId }, tollBooth);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllTollBooths()
        {
            try
            {
                var tollBooths = await _context.TollBooths.ToListAsync();
                if (tollBooths.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Toll Booths Found",
                        Data = tollBooths
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Booths Successfully",
                    Data = tollBooths
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetTollBoothById(long id)
        {
            try
            {
                var tollBooth = await _context.TollBooths.FindAsync(id);
                if (tollBooth == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Booth Not Found",
                        Data = tollBooth
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Booth Successfully",
                    Data = tollBooth
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTollBooth(long id, TollBoothDto tollBoothDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingTollBooth = await _context.TollBooths.FindAsync(id);
                if (existingTollBooth == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Booth Not Found",
                        Data = existingTollBooth
                    });
                }

                _mapper.Map(tollBoothDto, existingTollBooth);

                // Additional logic can be added here, such as validation or data processing

                _context.TollBooths.Update(existingTollBooth);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Toll Booth Updated Successfully",
                    Data = existingTollBooth
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpGet("admin/{boothId}")]
        public async Task<IActionResult> GetAdminDetailsByBoothId(long boothId)
        {
            try
            {
                var tollBooth = await _context.TollBooths.FindAsync(boothId);
                if (tollBooth == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Toll Booth Not Found",
                        Data = tollBooth
                    });
                }

                // Assuming you have a navigation property in your TollBooth model called 'Admin'
                var adminDetails = tollBooth.admin;

                if (adminDetails == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Admin Details Not Found for this Toll Booth",
                        Data = adminDetails
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Admin Details Successfully",
                    Data = adminDetails
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("all-booth-details")]
        public async Task<IActionResult> GetAllBoothDetails()
        {
            try
            {
                var boothDetails = await _context.TollBooths
                    .Include(tb => tb.admin) // Include related Admin details if you have a navigation property
                    .ToListAsync();

                if (boothDetails.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Booth Details Found",
                        Data = boothDetails
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve All Booth Details Successfully",
                    Data = boothDetails
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("booth-wise")]
        public async Task<IActionResult> GetTollRatesByBooth()
        {
            try
            {
                // Join TollRates with VehicleClasses to get vehicle names
                var tollRatesByBooth = await _context.TollRates
                    .Include(tr => tr.tollBooth) // Include TollBooth information if needed
                    .Join(_context.VehicleClasses,
                        tr => tr.VehicleClassId,
                        vc => vc.VehicleClassId,
                        (tr, vc) => new
                        {
                            BoothId = tr.BoothId,
                            VehicleName = vc.VehicleName,
                            TollAmount = tr.TollAmount,
                            EffectiveDate = tr.EffectiveDate
                        })
                    .GroupBy(tr => tr.BoothId)
                    .ToListAsync();

                if (tollRatesByBooth == null || !tollRatesByBooth.Any())
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Toll Rates Found",
                        Data = tollRatesByBooth
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Toll Rates by Booth with Vehicle Names Successfully",
                    Data = tollRatesByBooth
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [Authorize(Roles ="Admin")]
        [HttpGet("list-admin-details")]
        public async Task<IActionResult> ListAdminDetailsByBoothId()
        {
            try
            {
                var boothAdminDetails = await _context.TollBooths
                    .Include(tb => tb.admin) // Include related Admin details if you have a navigation property
                    .Select(tb => new
                    {
                        BoothId = tb.BoothId,
                        AdminDetails = tb.admin
                    })
                    .ToListAsync();

                if (boothAdminDetails == null || !boothAdminDetails.Any())
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Booth Admin Details Found",
                        Data = boothAdminDetails
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Booth Admin Details Successfully",
                    Data = boothAdminDetails
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }





    }
}
