using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Tollgate.context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class FastTagTypeController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public FastTagTypeController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateFastTagType(FastTagTypeDto fastTagTypeDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var fastTagType = _mapper.Map<FastTagTypeDto, FastTagType>(fastTagTypeDto);

                // Additional logic can be added here, such as validation or data processing

                await _context.FastTagTypes.AddAsync(fastTagType);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetFastTagTypeById), new { id = fastTagType.FastTagTypeid }, fastTagType);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllFastTagTypes()
        {
            try
            {
                var fastTagTypes = await _context.FastTagTypes.ToListAsync();
                if (fastTagTypes.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No FastTag Types Found",
                        Data = fastTagTypes
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve FastTag Types Successfully",
                    Data = fastTagTypes
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetFastTagTypeById(long id)
        {
            try
            {
                var fastTagType = await _context.FastTagTypes.FindAsync(id);
                if (fastTagType == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "FastTag Type Not Found",
                        Data = fastTagType
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve FastTag Type Successfully",
                    Data = fastTagType
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateFastTagType(long id, FastTagTypeDto fastTagTypeDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingFastTagType = await _context.FastTagTypes.FindAsync(id);
                if (existingFastTagType == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "FastTag Type Not Found",
                        Data = existingFastTagType
                    });
                }

                _mapper.Map(fastTagTypeDto, existingFastTagType);

                // Additional logic can be added here, such as validation or data processing

                _context.FastTagTypes.Update(existingFastTagType);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "FastTag Type Updated Successfully",
                    Data = existingFastTagType
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}
