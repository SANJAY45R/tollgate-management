using System;
using System.IO;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Tollgate.Models;
using System.Net.Mime;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
#nullable disable

namespace Tollgate.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ImageController : ControllerBase
    {
        private readonly TollgateContext _context;

        public ImageController(TollgateContext context)
        {
            _context = context;
        }

        [HttpPost]
        public IActionResult UploadImage(IFormFile file)
        {
            try
            {
                if (file == null || file.Length == 0)
                {
                    return BadRequest("Invalid file");
                }

                // Generate a unique file name or use the original file name
                var fileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);

                // Create a new Image object
                var image = new ImageModel
                {
                    Filename = fileName
                };

                // Read the file into a byte array
                using (var memoryStream = new MemoryStream())
                {
                    file.CopyTo(memoryStream);
                    image.Data = memoryStream.ToArray();
                }

                // Save the image to the database
                _context.ImageModels.Add(image);
                _context.SaveChanges();

                // Return a response with the image ID or other relevant information
                return Ok(new { ImageId = image.ImageId, Message = "Image uploaded successfully" });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{imageId}")]
        public IActionResult GetImage(long imageId)
        {
            try
            {
                // Retrieve the image from the database based on the imageId
                var image = _context.ImageModels.Find(imageId);

                if (image == null)
                {
                    return NotFound("Image not found");
                }

                // Create a memory stream from the byte array
                var stream = new MemoryStream(image.Data);

                // Determine the content type based on the file extension
                // You may need to adjust this based on your specific requirements
                var contentType = "image/jpeg"; // Default to JPEG
                var fileExtension = Path.GetExtension(image.Filename)?.ToLower();

                if (fileExtension == ".png")
                {
                    contentType = "image/png";
                }

                else if (fileExtension == ".gif")
                {
                    contentType = "image/gif";
                }

                // Return the image as a file stream
                return File(stream, contentType);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }
        [HttpGet("all")]
        public IActionResult GetAllImages()
        {
            try
            {
                var images = _context.ImageModels.ToList();

                if (images == null || images.Count == 0)
                {
                    return NotFound("No images found");
                }

                var imageDataList = images.Select(image => new
                {
                    FileName = image.Filename,
                    Data = Convert.ToBase64String(image.Data) // Convert image data to Base64 string
                }).ToList();

                return Ok(new
                {
                    Status = "Success",
                    Message = "All images retrieved",
                    Data = imageDataList
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

    }
}


