using System;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.context;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class RenewalCardController : ControllerBase
    {
        private readonly TollgateContext _context;
        private readonly IMapper _mapper;

        public RenewalCardController(TollgateContext context, IMapper mapper)
        {
            _context = context;
            _mapper = mapper;
        }

        [HttpPost]
        public async Task<IActionResult> CreateRenewalCard(RenewalCardDto renewalCardDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var renewalCard = _mapper.Map<RenewalCardDto, RenewalCard>(renewalCardDto);


                await _context.RenewalCards.AddAsync(renewalCard);
                await _context.SaveChangesAsync();

                return CreatedAtAction(nameof(GetRenewalCardById), new { id = renewalCard.RenewalId }, renewalCard);
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetAllRenewalCards()
        {
            try
            {
                var renewalCards = await _context.RenewalCards.ToListAsync();
                if (renewalCards.Count == 0)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "No Renewal Cards Found",
                        Data = renewalCards
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Renewal Cards Successfully",
                    Data = renewalCards
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpGet("{id}")]
        public async Task<IActionResult> GetRenewalCardById(long id)
        {
            try
            {
                var renewalCard = await _context.RenewalCards.FindAsync(id);
                if (renewalCard == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Renewal Card Not Found",
                        Data = renewalCard
                    });
                }

                return Ok(new
                {
                    Status = "Success",
                    Message = "Retrieve Renewal Card Successfully",
                    Data = renewalCard
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateRenewalCard(long id, RenewalCardDto renewalCardDto)
        {
            try
            {
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                var existingRenewalCard = await _context.RenewalCards.FindAsync(id);
                if (existingRenewalCard == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "Renewal Card Not Found",
                        Data = existingRenewalCard
                    });
                }

                _mapper.Map(renewalCardDto, existingRenewalCard);

                // Additional logic can be added here, such as validation or data processing

                _context.RenewalCards.Update(existingRenewalCard);
                await _context.SaveChangesAsync();

                return Ok(new
                {
                    Status = "Success",
                    Message = "Renewal Card Updated Successfully",
                    Data = existingRenewalCard
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }


        [HttpPost("RenewFastTag")]
        public async Task<IActionResult> RenewFastTag(RenewalCardDto renewalCardDto)
        {
            try
            {
                // Find the FastTag by ID
                var fastTag = await _context.FasttagRegisterations
                    .Include(ft => ft.FastTagType) // Include FastTagType for Amount
                    .FirstOrDefaultAsync(ft => ft.FastTagId == renewalCardDto.FastTagId);

                if (fastTag == null)
                {
                    return NotFound(new
                    {
                        Status = "Failed",
                        Message = "FastTag Not Found",
                        Data = renewalCardDto
                    });
                }

               
                var daysUntilExpiration = (fastTag.ValidDate - DateTime.UtcNow).Days;

                if (daysUntilExpiration <= 2)
                {
                   
                    var newValidDate = fastTag.ValidDate.AddYears(1);

                  
                    var renewalCard = new RenewalCard
                    {
                        FastTagId = renewalCardDto.FastTagId,
                        RenewalDate = DateTime.UtcNow,
                        // PaymentId = renewalCardDto.PaymentId
                    };

                   
                    var renewalAmount = fastTag.FastTagType.Amount;

                    
                    fastTag.ValidDate = newValidDate;

                    
                    _context.RenewalCards.Add(renewalCard);
                    await _context.SaveChangesAsync();

                    return Ok(new
                    {
                        Status = "Success",
                        Message = "FastTag Renewed Successfully",
                        Data = new
                        {
                            RenewalDate = renewalCard.RenewalDate,
                            NewValidDate = newValidDate,
                            RenewalAmount = renewalAmount
                        }
                    });
                }
                else
                {
                    return BadRequest(new
                    {
                        Status = "Failed",
                        Message = "FastTag renewal is only allowed within 2 days of expiration.",
                        Data = renewalCardDto
                    });
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }



    }
}
