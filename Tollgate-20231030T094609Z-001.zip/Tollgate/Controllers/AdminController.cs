using AutoMapper;
using Tollgate.context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.Dto;
using Tollgate.Models;
using DevOne.Security.Cryptography.BCrypt;
#nullable disable

namespace Tollgate.Controllers;
[ApiController]
[Route("api/[controller]")]
public class AdminController : ControllerBase
{
    private TollgateContext _context;
    private IMapper _mapper;
    public AdminController(TollgateContext context, IMapper mapper)
    {
        _context = context;
        _mapper = mapper;
    }

    [HttpPost]
    public async Task<IActionResult>CreateAdmin(AdminDto adminDto)
    {
        if (!ModelState.IsValid)
        {
            return BadRequest();
        }
        string hash =BCrypt.Net.BCrypt.HashPassword(adminDto.Password);

        var ad = new Admin
        {
            AdminName = adminDto.AdminName,
            Address = adminDto.Address,
            Email = adminDto.Email,
           Password = hash,
           FirstName = adminDto.FirstName,
           LastName = adminDto.LastName,
           PhoneNumber = adminDto.PhoneNumber,
           Role = adminDto.Role
            
        };

        await _context.Admins.AddAsync(ad);
        await _context.SaveChangesAsync();

        return Ok(new
        {
            Status = "Sucess",
            Message = "Admin Created Sucessfully",
            Data = ad
        });
    }
    [HttpGet]
    public async Task<IActionResult> Getall()
    {
        var adminlist = await _context.Admins.ToListAsync();
        if (adminlist.Count == 0)
        {
            return Ok(new
            {
                Status = "Failed",
                Message = "Not Found",
                Data = adminlist
            });

        }
        return Ok(new
        {
            Status = "Sucess",
            Message = "Retrieve Admin details Sucessfully",
            Data = adminlist
        });
    }

    [HttpGet("GetbyId")]
    public async Task<IActionResult> Getbyid(long Id)
    {
        var adminlist = await _context.Admins.FindAsync(Id);
        if (adminlist == null)
        {
            return Ok(new
            {
                Status = "Failed",
                Message = "Notfound Admin details",
                Data = adminlist
            });

        }
        return Ok(new
        {
            Status = "Sucess",
            Message = "Retrieve Admin detail Sucessfully",
            Data = adminlist
        });
    }



}
