using AutoMapper;
using Tollgate.context;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Tollgate.Dto;
using Tollgate.Models;
using System.Globalization;
using Microsoft.AspNetCore.Authorization;


namespace Tollgate.Controllers
{
    [ApiController]
    [Route("/api[Controller]")]
    public class OwnerController : ControllerBase
    {
        private TollgateContext _context;


        public OwnerController(TollgateContext context)
        {
            _context = context;

        }
        [Authorize(Roles ="Admin")]
        [HttpGet]
        public async Task<IActionResult> Getall()
        {
            var own = await _context.Owners.ToListAsync();
            if (own.Count == 0)
            {
                return Ok(new
                {
                    Status = "Failed",
                    Message = "Notfound owner details",
                    Data = own
                });
            }

            return Ok(new
            {
                Status = "Sucess",
                Message = "Retrieve owner detail Sucessfully",
                Data = own
            });
        }
        [HttpGet("Getbyid")]
        public async Task<IActionResult> Getbyid(long id)
        {
            var own = await _context.Owners.FindAsync(id);
            if (own == null)
            {
                return Ok(new
                {
                    Status = "Failed",
                    Message = "Notfound owner details",
                    Data = own
                });
            }

            return Ok(new
            {
                Status = "Sucess",
                Message = "Retrieve owner details get by id  Sucessfully",
                Data = own
            });
        }
        [HttpPost]
        public async Task<IActionResult> CreateOwner(OwnerDto ownerDto)
        {
            try
            {
                
                if (!ModelState.IsValid)
                {
                    return BadRequest(ModelState);
                }

                DateTime dob;
                
                if (!DateTime.TryParseExact(ownerDto.DateOfBirth, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out dob))
                {
                    return BadRequest("Invalid date of birth format. Please use dd/MM/yyyy.");
                }
                 string formattedDob = dob.ToString("yyyy/MM/dd");

             
                var owner = new Owner
                {
                    OwnerName = ownerDto.OwnerName,
                    Password = ownerDto.Password,
                    Address = ownerDto.Address,
                    PhoneNumber = ownerDto.PhoneNumber,
                    DateOfBirth = formattedDob
        
                };
    
                
                await _context.Owners.AddAsync(owner);
                await _context.SaveChangesAsync();

               
                return Ok(new
                {
                    Status = "Success",
                    Message = "Owner created successfully",
                    Data = owner
                });
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex.Message}");
            }
        }




    }
}