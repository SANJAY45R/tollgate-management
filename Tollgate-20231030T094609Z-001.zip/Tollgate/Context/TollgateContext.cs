namespace Tollgate.context;

using System.Drawing;
using System.Security.Cryptography.X509Certificates;
using Microsoft.EntityFrameworkCore;
using Tollgate.Models;

public class TollgateContext : DbContext
{
    public TollgateContext(DbContextOptions<TollgateContext> options)
    : base(options)
    {

    }
    public virtual DbSet<Admin> Admins { get; set; }
    public virtual DbSet<Basis> Bases { get; set; }
    public virtual DbSet<FastTagPayment> FastTagPayments { get; set; }
    public virtual DbSet<FasttagRegisteration> FasttagRegisterations { get; set; }
    public virtual DbSet<FastTagType> FastTagTypes { get; set; }

    public virtual DbSet<RegisterationFeedback> RegisterationFeedbacks { get; set; }

    public virtual DbSet<Lane> Lanes { get; set; }
    public virtual DbSet<Owner> Owners { get; set; }
    public virtual DbSet<Rating> Ratings { get; set; }
    public virtual DbSet<RenewalCard> RenewalCards { get; set; }
    public virtual DbSet<TollBooth> TollBooths { get; set; }

    public virtual DbSet<ImageModel> ImageModels { get; set; }
    public virtual DbSet<Tollfees> Tollfees { get; set; }
    public virtual DbSet<TollPlazzaOperator> TollPlazzaOperators { get; set; }
    public virtual DbSet<TollRate> TollRates { get; set; }
    public virtual DbSet<Vehicle> Vehicles { get; set; }
    public virtual DbSet<VehicleClass> VehicleClasses { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        // Configure the one-to-one relationship between FastTagPayment and FasttagRegisteration
        modelBuilder.Entity<FastTagPayment>()
            .HasOne(fp => fp.fasttagRegisteration)
            .WithOne(fr => fr.FastTagPayment)
            .HasForeignKey<FastTagPayment>(fp => fp.FastTagId) // Specify the foreign key property
            .IsRequired(); // You can add this if the relationship is required

        // Other configurations...

        base.OnModelCreating(modelBuilder);



        {
            // Configure the ImageModel entity
            modelBuilder.Entity<ImageModel>()
                .HasKey(im => im.ImageId);

            // Configure the Owner entity
            modelBuilder.Entity<Owner>()
                .HasKey(o => o.OwnerId);

            // Configure the one-to-one relationship
            modelBuilder.Entity<Owner>()
                .HasOne(o => o.ImageModel)
                .WithOne(im => im.owner)
                .HasForeignKey<Owner>(o => o.ImageId); // Assuming ImageId is the foreign key in Owner

            // Additional configuration for your entities...

            base.OnModelCreating(modelBuilder);
        }

    }



}


