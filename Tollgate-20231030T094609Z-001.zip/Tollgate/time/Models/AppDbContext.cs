using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace time.Models
{
        public class AppDbContext : DbContext

        {
        public DbSet<Name> names { get; set; }
        }
}
