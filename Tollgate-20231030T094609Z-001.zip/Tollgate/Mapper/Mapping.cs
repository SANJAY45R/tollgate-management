using AutoMapper;
using Tollgate.Dto;
using Tollgate.Models;

namespace Tollgate.Mapper
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<AdminDto, Admin>();
            CreateMap<OwnerDto, Owner>();
            CreateMap<TollPlazzaOperatorDto,TollPlazzaOperator>();
            CreateMap<VehicleDto,Vehicle>();
            CreateMap<VehicleClassDto,VehicleClass>();
            CreateMap<FasttagRegisterationDto,FasttagRegisteration>();
            CreateMap<FastTagTypeDto, FastTagType>();
            CreateMap<TollBoothDto, TollBooth>();
            CreateMap<LaneDto, Lane>();
            CreateMap<TollfeesDto, Tollfees>();
            CreateMap<TollRateDto, TollRate>();
            CreateMap<RenewalCardDto,RenewalCard>();
        }

    }
}