using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using Tollgate.Dto;

namespace Tollgate.Models
{
    #nullable disable
    public class RegisterationFeedback
    {
        [Key]
        public int RegisterationFeedbackId{get;set;}
        [ForeignKey("Ratingid")]
        public int Ratingid{get;set;}
        [ForeignKey("PaymentId")]
        public long PaymentId { get; set; }

        public string Feedback{get;set;}

        public Rating rating{get;set;}

        public FastTagPayment fastTagPayment{get;set;}

    }
}