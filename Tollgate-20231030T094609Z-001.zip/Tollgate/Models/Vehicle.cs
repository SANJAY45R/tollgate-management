using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tollgate.Models;
#nullable disable

    public class Vehicle
    {
        [Key]
        public long VehicleId{get;set;}

        public string RegistrationNumber{get;set;}

        [ForeignKey("VehicleClassId")]
        public int VehicleClassId{get;set;}

        [ForeignKey("OwnerId")]
        public long OwnerId{get;set;}

        public Owner owner{get;set;}
        public VehicleClass vehicleClass{get;set;}

       

        
    }
