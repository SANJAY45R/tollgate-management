using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
#nullable disable

namespace Tollgate.Models
{
  public class Tollfees
  {
    [Key]
    public long TollfeesId { get; set; }
    [ForeignKey("VehicleId")]
    public long VehicleId{get;set;}

    [ForeignKey("VehicleClassId")]
    public int VehicleClassId { get; set; }
    [ForeignKey("TollPlazzaOperatorId")]
    public long TollPlazzaOperatorId { get; set; }
    [ForeignKey("LaneId")]
    public int LaneId { get; set; }

    public bool IsAvailableFastTagId { get; set; }

    public bool IsValidCard { get; set; }
    public double Amount { get; set; }

    public VehicleClass vehicleClass { get; set; }

    public Vehicle vehicle{get;set;}
    public Lane lanes { get; set; }

    public TollPlazzaOperator tollPlazzaOperator { get; set; }
  }
}