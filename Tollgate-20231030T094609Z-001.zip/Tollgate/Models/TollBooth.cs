using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tollgate.Models;
#nullable disable
    public class TollBooth
    {
        [Key]
        public long BoothId{get;set;}
        public string Location{get;set;}

        [ForeignKey("AdminId")]
        public long AdminId{get;set;}

        public  bool Isopen{get;set;}

        public Admin admin{get;set;}

        public ICollection<Lane> lanes{get;set;} = new List<Lane>();

        
    }
