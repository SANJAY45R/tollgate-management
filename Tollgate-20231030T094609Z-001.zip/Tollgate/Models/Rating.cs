using System.ComponentModel.DataAnnotations;
#nullable disable

namespace Tollgate.Models
{
    public class Rating
    {
        [Key]
        public int Ratingid{get;set;}

        public string RatingCategoryName{get;set;}

        // public ICollection<FasttagRegisteration> fasttagRegisterations {get;set;}= new List<FasttagRegisteration>();
    }
}