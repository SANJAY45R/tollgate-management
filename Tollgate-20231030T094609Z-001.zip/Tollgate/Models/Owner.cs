namespace Tollgate.Models;

using System;

using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
#nullable disable
public class Owner
    {

        [Key]
        public long OwnerId{get;set;}
        public string OwnerName{get;set;}
        public string Password{get;set;}
        [ForeignKey("ImageId")]
        public int ImageId{get;set;}

        public string Role{get;set;}
        public string PhoneNumber{get;set;}
        public string Address{get;set;}
        public string DateOfBirth{get;set;}

        public Vehicle vehicle {get;set;}

        public ImageModel ImageModel{get;set;}

}
