using System.ComponentModel.DataAnnotations;

namespace Tollgate.Models
{
    #nullable disable
    public class VehicleClass
    {
        [Key]
        public int VehicleClassId{get;set;}
        public string VehicleName{get;set;}
        public ICollection<Vehicle> Vehicles{get;set;} = new List<Vehicle>();
    }
}