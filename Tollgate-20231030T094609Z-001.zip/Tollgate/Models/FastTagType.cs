using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
#nullable disable

namespace Tollgate.Models
{
    public class FastTagType
    {
        [Key]
        public int FastTagTypeid{get;set;}

         [ForeignKey("BasisId")]
         public int BasisId{get;set;}
     
        [ForeignKey("VehicleId")]
         public long VehicleId{get;set;}

        public string FastTagTypeName{get;set;}

        public double Amount{get;set;}

        public Basis basis{get;set;}
        public Vehicle vehicle{get;set;}
        public ICollection<FasttagRegisteration> fasttagRegisterations{get;set;} = new List<FasttagRegisteration>();
    }
}