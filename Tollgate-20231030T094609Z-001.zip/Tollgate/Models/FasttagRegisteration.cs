using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
#nullable disable

namespace Tollgate.Models
{
    public class FasttagRegisteration
    {
        [Key]
        public long FastTagId { get; set; }
    
        [ForeignKey("VehicleId")]
        public long VehicleId { get; set; }
     

        public DateTime RegistrationTime { get; set; }
        public DateTime ValidDate { get; set; }

        [ForeignKey("FastTagType")]
        public int FastTagTypeid { get; set; }
        public FastTagType FastTagType { get; set; }

        [ForeignKey("BoothId")]
        public long BoothId { get; set; }

        public double TotalAmount{get;set;}
        public TollBooth Booth { get; set; }

        public bool RegistrationStatus { get; set; }

        public FastTagPayment FastTagPayment { get; set; }

        public Vehicle vehicle { get; set; }

        // Any other properties you want to include in this class
    }
}
