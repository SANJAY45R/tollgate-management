using System.ComponentModel.DataAnnotations;

namespace Tollgate.Models;

    #nullable disable
    public class Admin
    {
         [Key]
        public long AdminId{get;set;}

        [Required]
        public string AdminName{get;set;}

        [Required]
        public string Password{get;set;}

        public string Role{get;set;}
        
        public string Address{get;set;}
        [Phone]
        public string PhoneNumber{get;set;}
        [EmailAddress]
        public string Email{get;set;}

        public string FirstName{get;set;}

        public char LastName{get;set;}
    }
