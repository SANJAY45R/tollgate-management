using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Security.Cryptography;

namespace Tollgate.Models
{
    #nullable disable
    public class FastTagPayment
    {
    [Key]
    public long PaymentId { get; set; }
    public double Amount { get; set; }
    [ForeignKey("FastTagId")]
    public long FastTagId{get;set;}
    public bool IsValid{get;set;}
    public DateTime PaymentDate { get; set; }
    public string PaymentMethod { get; set; }
    public string TransactionId { get; set; }
    public bool IsSuccessful { get; set; }
     public FasttagRegisteration fasttagRegisteration{get;set;}
    }
    
}