using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tollgate.Models
{
    #nullable disable
    public class TollRate
    {
        [Key]
        public long TollRateId{get;set;}
        [ForeignKey("BoothId")]
        public long BoothId{get;set;}
        [ForeignKey("VehicleClassId")]
        public int VehicleClassId{get;set;}
        public double TollAmount{get;set;}

        public DateTime EffectiveDate{get;set;}    
        public VehicleClass vehicleClass{get;set;}

        public TollBooth tollBooth{get;set;}

    }
}