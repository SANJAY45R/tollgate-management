using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Tollgate.Models;
#nullable disable
public class RenewalCard{
    [Key]
    public long RenewalId{get;set;}
    [ForeignKey("FastTaId")]
    public long FastTagId{get;set;}

    public DateTime RenewalDate{get;set;}

    public FastTagPayment fastTagPayment{get;set;}


}