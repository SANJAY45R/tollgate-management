using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
#nullable disable

namespace Tollgate.Models
{
    public class Lane
    {
        [Key]
        public int LaneId{get;set;}
        [ForeignKey("BoothId")]
        public long BoothId{get;set;}

        public string LaneName{get;set;}

        public TollBooth tollBooth{get;set;}
    }
}