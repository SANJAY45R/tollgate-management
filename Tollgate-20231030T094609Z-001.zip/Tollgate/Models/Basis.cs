using System.ComponentModel.DataAnnotations;
#nullable disable

namespace Tollgate.Models
{
    public class Basis
    {
        [Key]
        public int BasisId{get;set;}

        public string BasisName{get;set;} 
        
    }
}