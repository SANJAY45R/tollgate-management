namespace Tollgate.Models
#nullable disable
{
    public class PaginationModel<T>
    {
        public int PageNumber{get;set;}
        public int PagewiseData{get;set;}

        public int TotalNumberOfData{get;set;}

        public int Pages => TotalNumberOfData / PagewiseData;

        public List<T> Data {get;set;}  


    }

   

}