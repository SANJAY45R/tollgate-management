using System.ComponentModel.DataAnnotations;

namespace Tollgate.Models
#nullable disable
{
    public class ImageModel
    {
    
        [Key]

        public int ImageId{get;set;}

        public string Filename{get;set;}
        public byte[] Data{get;set;} 

        public Owner owner{get;set;}
    }
}